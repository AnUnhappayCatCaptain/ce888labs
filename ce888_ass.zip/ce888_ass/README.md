# ce888 Assignment

## Step 1. Data loading and Splitting (Completed)

* The results (two .txt files including directories of images and differences) of step 1 could be found in th folder.  

* The specific procedure of loading and processing the data is described in .ipynb file.  
  1. Test dataset will include 10000 data;  
  2. Train dataset will only include 5 data (as the topic requires data should not be much )  
  3. In fact, the train data should only be 1.  
  
## Step 2. (Wait for editing)  

## Step 3. (Wait for editing)  

## Step 4. (Wait for editing)  

## Step 5. (Wait for editing)  